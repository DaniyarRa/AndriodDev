package com.example.a6;



import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import java.io.FileReader;
import java.io.FileWriter;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.core.app.ActivityCompat;

public class MainActivity extends Activity {

    private MediaRecorder mediaRecorder;
    private MediaPlayer mediaPlayer;
    private String fileName;

    ImageView im;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/audio.3gpp";

        im = (ImageView) findViewById(R.id.image);
        im.setClickable(true);
        im.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openNewActivity();
            }
        });

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.MANAGE_EXTERNAL_STORAGE ,Manifest.permission.WRITE_EXTERNAL_STORAGE ,Manifest.permission.READ_EXTERNAL_STORAGE ,Manifest.permission.RECORD_AUDIO ,Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS}, PackageManager.PERMISSION_GRANTED);

    }
    public void openNewActivity(){
        Intent intent = new Intent(this, SecondActivity.class);
        startActivity(intent);
    }



    public void recordStart(View v) {
        try {
            releaseRecorder();

            File outFile = new File(fileName);
            if (outFile.exists()) {
                outFile.delete();
            }

            mediaRecorder = new MediaRecorder();
            mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediaRecorder.setOutputFile(fileName);
            mediaRecorder.prepare();
            mediaRecorder.start();
            Thread.sleep(5000);
            if (mediaRecorder != null) {
                mediaRecorder.stop();
            }
            System.out.println("sending process has started");
            send_message();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void recordStop(View v) {
        if (mediaRecorder != null) {
            mediaRecorder.stop();
        }
    }

    public void send_message(){
        try {
            FileReader fr2 = new FileReader(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/num.txt");
            char[] array2 = new char[12];
            fr2.read(array2);
            SmsManager sm = SmsManager.getDefault();
            //PendingIntent sentPI;
            //String SENT = "SMS_SENT";

            //sentPI = PendingIntent.getBroadcast(this, 0,new Intent(SENT), 0);
            //sm.getDefault().sendTextMessage(String.valueOf(array2), null, "Hello", sentPI, null);
            //sm.getDefault().sendMultimediaMessage( getApplicationContext(), Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/audio.3gpp"), null, null, sentPI);
            final PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this, 0, new Intent("SMS_SENT"), 0);

            SmsManager.getDefault().sendMultimediaMessage(getApplicationContext(),
                    Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/audio.3gpp"), null, null,
                    pendingIntent);


            PendingIntent intent = PendingIntent.getBroadcast(
                    this, 0, new Intent("SMS_SEND"), 0);

            SmsManager.getDefault().sendTextMessage(String.valueOf(array2).trim(), null, "I am in dangerous", pendingIntent, intent);

            System.out.println("sended_message: " + String.valueOf(array2));
            fr2.close();

        }catch (Exception e)
        {
            String error="";
            error=e.getMessage();
        }
    }
    public void playStart(View v) {
        try {
            releasePlayer();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(fileName);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void playStop(View v) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
        }
    }

    private void releaseRecorder() {
        if (mediaRecorder != null) {
            mediaRecorder.release();
            mediaRecorder = null;
        }
    }

    private void releasePlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        releasePlayer();
        releaseRecorder();
    }

}