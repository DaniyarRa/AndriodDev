package com.example.a6;

import android.app.Activity;
import android.os.Bundle;

import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;


import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;


public class SecondActivity extends Activity {

    private static final String TAG = "1";
    ImageView im2;
    ImageView im3;
    Button b1;
    EditText et1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);

        im2 = findViewById(R.id.im2);
        im3 = findViewById(R.id.im3);
        b1 = findViewById(R.id.tw2);
        et1 = findViewById(R.id.editText);
        im2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                add_new();
            }
        });

        im3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                delete_one();
            }
        });

        try
        {
            FileReader fr = new FileReader(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/num.txt");

            et1.setText( fr.read());
            fr.close();
        }
        catch (Exception e)
        {
            String error="";
            error=e.getMessage();
        }

        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                    try
                    {
                        FileWriter fw = new FileWriter(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/num.txt");



                        fw.write(et1.getText().toString());
                        fw.flush();

                        fw.close();

                        FileReader fr3 = new FileReader(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Music/num.txt");
                        char[] array = new char[12];
                        fr3.read(array);
                        System.out.println("saved_number: " + String.valueOf(array));
                        fr3.close();
                    }
                    catch (Exception e)
                    {
                        String error="";
                        error=e.getMessage();
                    }
            };
        });
    }

    public void add_new(){

    }
    public void delete_one(){

    }
}